const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const { notFound, errorHandler } = require('./middlewares/error');

const app = express();

app.set('trust proxy', 1);
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '100kb' }));

app.get('/health', (_req, res) => res.json({ ok: true }));

app.use('/api/customers', require('./routes/customers.routes'));
app.use('/api/google', require('./routes/google.routes'));
app.use('/api', require('./routes/scan.routes'));
app.use('/apple', require('./routes/apple.routes'));

app.use(notFound);
app.use(errorHandler);

module.exports = app;
