require('dotenv').config();
const path = require('path');

const env = process.env;
const root = path.resolve(__dirname, '../..');
const abs = (p) => (p ? path.resolve(root, p) : null);

const port = Number(env.PORT) || 3000;

const config = {
  port,
  baseUrl: (env.BASE_URL || `http://localhost:${port}`).replace(/\/$/, ''),
  staffApiKey: env.STAFF_API_KEY,
  dbPath: abs(env.DB_PATH || 'data/loyalty.db'),

  program: {
    name: env.PROGRAM_NAME || 'Mi Cafetería',
    stampsRequired: Number(env.STAMPS_REQUIRED) || 10,
    cashbackRate: Number(env.CASHBACK_RATE ?? 0.05),
    rewardDiscountPct: Number(env.REWARD_DISCOUNT_PCT) || 20,
    currency: env.CURRENCY || 'USD',
    bg: env.BRAND_BG || 'rgb(30, 41, 59)',
    fg: env.BRAND_FG || 'rgb(255, 255, 255)',
    label: env.BRAND_LABEL || 'rgb(203, 213, 225)',
    hex: env.BRAND_HEX || '#1e293b',
  },

  apple: {
    passTypeIdentifier: env.APPLE_PASS_TYPE_ID,
    teamIdentifier: env.APPLE_TEAM_ID,
    apnsHost: env.APNS_HOST || 'api.push.apple.com',
    certs: {
      wwdr: abs(env.APPLE_WWDR_CERT || 'certs/wwdr.pem'),
      signerCert: abs(env.APPLE_SIGNER_CERT || 'certs/signerCert.pem'),
      signerKey: abs(env.APPLE_SIGNER_KEY || 'certs/signerKey.pem'),
      signerKeyPassphrase: env.APPLE_SIGNER_KEY_PASSPHRASE || undefined,
    },
    modelDir: path.join(root, 'assets/apple/loyalty.pass'),
  },

  google: {
    issuerId: env.GOOGLE_ISSUER_ID,
    classSuffix: env.GOOGLE_CLASS_SUFFIX || 'fidelidad_v1',
    serviceAccountFile: abs(env.GOOGLE_SERVICE_ACCOUNT_FILE || 'certs/google-service-account.json'),
    origins: (env.GOOGLE_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean),
    logoUrl:
      env.GOOGLE_LOGO_URL ||
      'https://storage.googleapis.com/wallet-lab-tools-codelab-artifacts-public/pass_google_logo.jpg',
  },
};

if (!config.staffApiKey) {
  throw new Error('Falta STAFF_API_KEY en el .env (protege /api/scan y /api/redeem).');
}

module.exports = config;
