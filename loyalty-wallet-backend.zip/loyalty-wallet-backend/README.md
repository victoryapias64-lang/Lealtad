# Backend de tarjetas de fidelización (Apple Wallet + Google Wallet)

Sellos, cashback y descuentos. Node.js + Express + SQLite.

## Inicio rápido

```bash
npm install
cp .env.example .env        # completa los valores
npm run assets              # genera pass.json + iconos placeholder (cámbialos por tu branding)
npm run setup:google        # crea la clase de lealtad en Google Wallet (una vez)
npm run dev
```

Sin certificados el servidor arranca igual: Apple/Google responden 503 hasta que los configures.

## Estructura

```
src/
  config/      variables de entorno y reglas del programa
  db/          SQLite (clientes, tarjetas, dispositivos Apple, transacciones)
  middlewares/ auth (staff / ApplePass), validación zod, errores
  services/
    loyalty.service.js       reglas: sellos, cashback, recompensas
    apple.service.js         genera el .pkpass (passkit-generator)
    apns.service.js          push a Apple (HTTP/2)
    google.service.js        clase/objeto, JWT "Save to Wallet", PATCH + mensajes
    notification.service.js  orquesta ambas wallets
  routes/      customers, scan, google, apple (web service PassKit)
scripts/       assets placeholder, setup de la clase de Google
```

## Endpoints

| Método | Ruta | Auth | Descripción |
|---|---|---|---|
| POST | `/api/customers` | — | Registra cliente (idempotente por email) y devuelve enlaces |
| GET | `/api/customers/:id/apple` | — | Descarga el `.pkpass` |
| GET | `/api/customers/:id/google` | — | URL "Agregar a Google Wallet" (JWT). `?redirect=1` redirige |
| GET | `/api/customers/:id` | x-api-key | Estado de la tarjeta |
| POST | `/api/scan` | x-api-key | Suma sellos/cashback + notifica Apple y Google |
| POST | `/api/redeem` | x-api-key | Canjea un descuento disponible |
| POST | `/api/google/sync/:serial` | x-api-key | Fuerza sincronizar el objeto de Google |
| * | `/apple/v1/...` | ApplePass | Web service PassKit (lo llama Wallet) |

```bash
# Registrar
curl -X POST localhost:3000/api/customers -H 'Content-Type: application/json' \
  -d '{"name":"Ana Pérez","email":"ana@example.com"}'

# Escanear (code = serial del QR). amount es opcional (cashback)
curl -X POST localhost:3000/api/scan -H 'Content-Type: application/json' \
  -H 'x-api-key: TU_STAFF_API_KEY' -d '{"code":"<serial>","stamps":1,"amount":12.5}'
```

## Apple Wallet

1. Crea un **Pass Type ID** y su certificado en developer.apple.com; descarga también el WWDR (G4).
2. Convierte a PEM y colócalos en `certs/`:
   ```bash
   openssl pkcs12 -in Certificates.p12 -clcerts -nokeys -out certs/signerCert.pem
   openssl pkcs12 -in Certificates.p12 -nocerts -out certs/signerKey.pem
   openssl x509 -inform der -in AppleWWDRCAG4.cer -out certs/wwdr.pem
   ```
3. `BASE_URL` debe ser **HTTPS público** (en local: ngrok / cloudflared). Wallet llama a `BASE_URL/apple/v1/...`.
4. Flujo de actualización: `/api/scan` -> APNs (push vacío) -> Wallet pide `/apple/v1/devices/...` -> descarga el pase nuevo. El texto de la notificación sale del `changeMessage` del campo que cambió.

## Google Wallet

1. Crea un Issuer en la Google Pay & Wallet Console y anota el **Issuer ID**.
2. Crea una cuenta de servicio, habilita la Google Wallet API, descarga el JSON a `certs/google-service-account.json` y agrega su email como usuario del Issuer en la consola.
3. `npm run setup:google` crea la clase (en modo demo solo funciona con usuarios de prueba hasta que Google la apruebe).
4. Alta del pase: el enlace `/api/customers/:id/google` entrega un **JWT RS256** con el objeto embebido. Las actualizaciones posteriores usan `PATCH` autenticado con la misma cuenta de servicio, más `addMessage` (`TEXT_AND_NOTIFY`) para la notificación (Google limita su frecuencia).

## Reglas del programa (`.env`)

`STAMPS_REQUIRED` sellos = 1 descuento de `REWARD_DISCOUNT_PCT`%. `CASHBACK_RATE` se aplica sobre `amount` en cada scan.

## Producción

Detrás de HTTPS, `STAFF_API_KEY` larga y rotada, rate limiting en el proxy, y SQLite -> Postgres si escalas a varias instancias.
